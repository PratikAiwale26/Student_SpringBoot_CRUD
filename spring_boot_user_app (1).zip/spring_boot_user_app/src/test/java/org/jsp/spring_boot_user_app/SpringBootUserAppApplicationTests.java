package org.jsp.spring_boot_user_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootUserAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
